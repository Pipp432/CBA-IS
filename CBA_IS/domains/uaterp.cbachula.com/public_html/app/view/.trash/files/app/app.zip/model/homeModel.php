<?php

namespace model;

use DateTime;

use _core\model;
use _core\helper\input;
use _core\helper\session;

class homeModel extends model {

}