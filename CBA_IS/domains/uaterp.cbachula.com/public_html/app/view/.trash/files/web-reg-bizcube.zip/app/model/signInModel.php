<?php

namespace model;

use _core\model;

class signInModel extends model {

}
