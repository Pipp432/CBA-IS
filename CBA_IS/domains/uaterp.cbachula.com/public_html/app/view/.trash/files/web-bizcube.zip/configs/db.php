<?php

define('DB_TYPE','mysql');
define('DB_HOST','localhost');
define('DB_NAME','cbachula_bizcube');
define('DB_USER','cbachula_bizcube');
define('DB_PASS','Bizcube2021');

?>