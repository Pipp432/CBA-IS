<!DOCTYPE html>
<html>

    <head>
        <?php require 'style.php'; ?>
        <script> var app = new Vue({el: '#app', data: null}); </script>
    </head>

    <body id="app">
        <?php 
            if($this->contents != null) {
                foreach ($this->contents as $content) {
                    require 'app/view/'.$content.'.php';
                }
            }
        ?>
    </body>

</html>