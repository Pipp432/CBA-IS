<!DOCTYPE html>
<html>

<body>

    <div class="container-fluid px-0" ng-controller="moduleAppController">
        
        <div class="container pt-1">

            <h2 class="mt-3">ใบเบิกเงิน - Cash Disbursement (CD)</h2>

        </div>

    </div>
    
</body>

</html>

<script>

    app.controller('moduleAppController', function($scope, $http) {

    });

</script>