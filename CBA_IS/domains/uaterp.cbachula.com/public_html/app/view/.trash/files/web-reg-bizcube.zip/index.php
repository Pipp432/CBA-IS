<?php

function autoloadClass($className) {
    $dir = str_replace('\\','/',$className);
    $file = 'app/'.$dir.'.php';
    require_once $file;
}

spl_autoload_extensions('.php');
spl_autoload_register('autoloadClass');

require_once 'configs/db.php';

use _core\main;

$main = new main();