var LIFF_ID = "1655997889-Br3683yr";
var API_URL = "/";
var personal_info_request_text = "/personal_info";
var personal_info_response_intent = "pageview_personal_info"
var personal_breakdown_request_text = "/personal_info/breakdown";
var personal_breakdown_response_intent= "pageview_personal_info_breakdown";
var LINE_USER_ID = null;
var cbaChart = null;


if(document.location.href.includes('line.cbachula.com')){
  LIFF_ID = '1655997889-O3QRrQM4';
}else{
  API_URL = 'https://cbauat.bearrunrun.com/';
  // API_URL = 'https://line.cbachula.com/';
}

function generateQRCode(qr_text) {
  let qr = new QRious({
        element: document.getElementById('profile_qr_code'),
        size: 146,
        value: qr_text
  });
}

function get_line_profile() {
  liff.getProfile().then(result => {
    $('#profile_img').attr('src', result.pictureUrl);
    $('#profile_name').text(result.displayName);
    check_is_liked_and_redirect(result.userId);
    
  }).catch((err) => {

    $('#profile_img').attr('src', 'https://cbachula.com/cba-chula-logo.png');
    $('#profile_name').text('DEMO');
    LINE_USER_ID = 'U79e24611b0667e408c8903ca9f914486';
    get_cba_profile('U79e24611b0667e408c8903ca9f914486');
  });
}

function get_cba_profile(line_user_id){
  LINE_USER_ID = line_user_id;
  let url = `${API_URL}api/personal_info?line_user_id=${line_user_id}`;
  $.get( url, function( data ) {
    let remain_point_percent = (data.point/data.full_point)* 100;
    let remain_point_next_rank = numberWithCommas(data.full_point - data.point);
    $('#profile_name').text(data.name);
    $('#profile_spid').text(data.sp_id);
    //point main
    $('#profile_full_point').text(numberWithCommas(data.full_point));
    $('#profile_point').text(numberWithCommas(data.point));
    $('#profile_point_remain').attr('style', `width: ${remain_point_percent}%;`);
    // point modal
    $('#profile_full_point_modal').text(numberWithCommas(data.full_point));
    $('#profile_point_modal').text(numberWithCommas(data.point));
    $('#profile_point_remain_modal').attr('style', `width: ${remain_point_percent}%;`);
    // $('#profile_point_remain_2').attr('style', `width: ${remain_point_percent}%;`);
    $('#profile_rank').text(data.rank);
    $('#profile_sale_remain').text(numberWithCommas(remain_point_next_rank));
    $('#profile_sales').text(numberWithCommas(data.sales));
    $('#profile_social_impact').text(numberWithCommas(data.social_impact));
    $('#profile_next_rank').text(data.next_rank);
    $('#profile_ranking').text(data.ranking);
    if(!data.show_nextrank){
      $('#next_rank_area1').attr('style', 'display:none');
      $('#next_rank_area2').attr('style', 'display:none');
    }
    if(data.show_check_in){
      $('#section_checkin').attr('style', 'display:');
    }else{
      $('#section_checkin').attr('style', 'display:none');
    }
    init_point_breakdown(data.point_logs);
    generateQRCode(data.sp_id);
  });
}

function initializeLiff() {
    liff.init({liffId: LIFF_ID})
      .then(() => {
          get_line_profile();
      })
      .catch((err) => {
        console.log(err);
      });
}

var is_toggle_send = false;
function toggle_modal(){
  $( "#profile_modal" ).toggle( "fast", function() {
    if(!is_toggle_send){
      is_toggle_send = true;
      send_analytics(LINE_USER_ID, personal_breakdown_request_text, personal_breakdown_response_intent);
    }
  });
}

function init_point_breakdown(point_breakdown_data){
  create_point_breakdown_graph(point_breakdown_data);
  create_point_breakdown_table(point_breakdown_data);
}

function create_point_breakdown_table(point_breakdown_data){

  $.each(point_breakdown_data , function(index, item){
    $('#profile_point_breakdown_table > tbody:last-child').append(
      `<tr>
        <td class="text-text-3" style="font-size: 12px" width="70px">${get_date_format(item.recent_date)}</td>
        <td class="text-text-3" style="font-size: 12px">${item.remark}</td>
        <td>${item.type}</td>
        <td class="text-primary">${item.point}</td>
      </tr>`
    );
  });
  
}

function get_point_label_count(point_breakdown_data){
  var labels_sum_dict = {};
  for(let item of point_breakdown_data){
    if(!(item.type in labels_sum_dict)){
      labels_sum_dict[item.type] = 0;
    }
    labels_sum_dict[item.type] = labels_sum_dict[item.type] + Number(item.point);
  }

  var label_arr = [];
  var label_sum = [];
  for(var key in labels_sum_dict){
    label_arr.push(key);
    label_sum.push(labels_sum_dict[key]);
  }

  return {
    labels:label_arr,
    data : label_sum
  };
}

function checkin(){
  let url = `${API_URL}liff/check_name?line_user_id=${LINE_USER_ID}`;
  $.get( url, function( data ) {
    alert(data.message);
    $('#section_checkin').attr('style', 'display:none');
    get_line_profile();
  });
}

function get_chart_data(label_data){
  return {
    labels: label_data.labels,
    datasets: [{
      label: 'CBA Pie Chart',
      cutout: '65%',
      data: label_data.data,
      backgroundColor: [
        'rgb(155, 75, 255)',
        'rgb(235, 56, 17)',
        'rgb(13, 157, 255)',
        'rgb(255, 218, 67)',
        'rgb(65, 242, 156)'
      ],
      hoverOffset: 4
    }]
  };
}

function create_point_breakdown_graph(point_breakdown_data){
  var label_data = get_point_label_count(point_breakdown_data);
  var ctx = document.getElementById('myChart').getContext('2d');
  var data = get_chart_data(label_data);
  if(cbaChart){
    cbaChart.data = data
    cbaChart.update();
  }else{
    cbaChart = new Chart(ctx, {
        type: 'doughnut',
        data: data,
        options: {
          responsive: true,
          maintainAspectRatio: true, 
          plugins: {
            legend: {
              display: true,
              position: 'right',
              labels:{
                usePointStyle: true,
                font: {
                  size: 12
              }
            }
          }
        }
      }
    });
  }
}