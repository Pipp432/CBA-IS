var LIFF_ID = "1655997889-RagYQgBy";
var API_URL = "/";
var FORM_USER_OBJECT = null;
const menu_activity = 3;
var BRR_API_URL = "https://linecms.cbachula.com/"
var activity_request_text = "/activity";
var activity_info_response_intent = "pageview_activity"
var activity_join_request_text = "/activity/join/{activity_id}";
var activity_join_response_intent= "joinevent_{activity_id}";
var LINE_USER_ID = null;
var JOIN_ACTIVITY_ID = null;


if(document.location.href.includes('line.cbachula.com')){
  LIFF_ID = '1655997889-n1qeAq8Q';
}else{
  API_URL = 'https://cbauat.bearrunrun.com/';
  // API_URL = 'https://line.cbachula.com/';
}


function get_line_profile() {
  liff.getProfile().then(result => {
    check_is_liked_and_redirect(result.userId);
    get_cba_activity(result.userId);
    get_cba_form_profile(result.userId);
    send_analytics(result.userId, activity_request_text, activity_info_response_intent);
  }).catch((err) => {
    get_cba_activity('test');
    get_cba_form_profile('U79e24611b0667e408c8903ca9f914486');
  });
}

function get_cba_activity(line_user_id){
  LINE_USER_ID = line_user_id;
  let url = `${BRR_API_URL}api/cms/layout/get_contents_by_ids?menu_id=${menu_activity}`;
  $.get( url, function( data ) {
    if(data.response_code == 200){
      append_activity_data(data.result);
    }else{
      alert(data.response_msg);
    }
    
  });
}

function append_activity_data(activity_list){
  if(activity_list.length > 0){
    $.each(activity_list , function(index, item){
      $('#main_activity_list').append(
        `<div class="activity__list" >
          <img class="portrait" src="${item.images}" alt="">
          <div class="p-5">
            <div class="title">${item.title}</div>
            <div class="date">${item.period_present}</div>
            <div class="p-5"><button class="button block" onclick="start_join_activity(${item.id})">${item.button_name}</button></div>
            <hr class="mb-5">
            <p class="paragraph">${item.detail}</p>
            <div class="collapse__tool" style="display:none">ย่อ <i class="fas fa-caret-up ml-1"></i></div>
          </div>
        </div>`
      );
    });
  }else{
    $('#main_activity_list').append(
      `<div class="activity__list" >
        <div class="p-5">
          <div class="title">No activity result.</div>
        </div>
      </div>`
    );
  }
}

function start_join_activity(id){
  JOIN_ACTIVITY_ID = id;
  $('#activity_form_modal').toggle();
}

function cancle_join_activity(){
  JOIN_ACTIVITY_ID= null;
  $('#activity_form_modal').toggle();
}

function join_activity(){
  $('#activity_form_modal').hide();
  $('#activity_thankyou_modal').show();
}

function close_thankyou_join(){
  JOIN_ACTIVITY_ID= null;
  $('#activity_form_modal').hide();
  $('#activity_thankyou_modal').hide();
}

function initializeLiff() {
    liff.init({liffId: LIFF_ID})
      .then(() => {
          get_line_profile();
      })
      .catch((err) => {
        console.log(err); 
      });
}


function get_cba_form_profile(line_user_id){
  let url = `${API_URL}api/form_profile?line_user_id=${line_user_id}`;
  $.get( url, function( data ) {
    $('#form_profile_name').text(data.name);
    $('#form_profile_tel').text(data.tel);
    $('#form_profile_sp_id').text(data.sp_id);
    FORM_USER_OBJECT = data;
  });
}