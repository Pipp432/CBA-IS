add_modal('showSosValidate1', 'ยังไม่ได้เลือกลูกค้า');
add_modal('showSosValidate2', 'ยังไม่ได้เลือก SO ที่จะสร้าง SOX');
add_modal('showSosValidate3', 'ไม่สามารถรวม SOX ข้ามโครงการได้');

function toggle() {
    checkboxes = document.getElementsByName('SOcheck');
    for(var i = 0, n = checkboxes.length; i < n ; i++) {
        checkboxes[i].checked = document.getElementById("selectall").checked;
    }
}

function formatNumber(num) {
    return parseFloat(num).toFixed(2).replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,');
}

var soNoSoxs = [];

app.controller('appController', function($scope, $http) {

    $scope.done = false;
    $scope.sos = [];

    liff.init({liffId: '1655997889-JnGWnG3L'}, () => {
        liff.getProfile().then(result => {
            $http.get('/api/check_line_user_id?line_user_id=' + result.userId).then((response) => {
                if (response.data.is_existing) {
                    send_analytics(result.userId, '/my_orders/create_sox', 'pageview_my_orders_create_sox');
                    $http.get('/my_orders/get_sos_no_sox?line_user_id=' + response.data.line_user_id).then((response) => {
                        $scope.sos = response.data;
                        soNoSoxs = $scope.sos;
                        var customerList = [];
                        angular.forEach($scope.sos, value => {
                            if (!customerList.includes(value.customer_tel)) {
                                $('#customerName').append('<option value="' + value.customer_tel + '">คุณ' + value.customer_name + ' ' + value.customer_surname + '</option>');
                                customerList.push(value.customer_tel);
                            }
                        });
                        $scope.done = true;
                    });
                } else {
                    location.assign('/signin?liff_id=1655997889-JnGWnG3L');
                }
            });
        });
    }, err => console.error(err.code, error.message));

    $scope.weight = 0;

    // $scope.showSos = () => {

    //     $scope.weight = 0;
                
    //     if($('#customerName').val() == '') {
            
    //         $('#showSosValidate1').modal('toggle');
            
    //     } else {
            
    //         $('#customerName').attr('disabled', true);
    //         $('#showSos').attr('disabled', true);
    //         $('body, html').animate({ scrollTop: $("#sos").offset().top }, 600);
            
    //         var soList = [];
    //         var hasSoNoSox = false;
            
    //         $('#sos').html('');
            
    //         angular.forEach($scope.sos, value => {
    //             if(!soList.includes(value.so_no) && value.customer_tel == $('#customerName').val()) {
    //                 $('#sos').append('<div class="container bg-white mx-0 mt-3 p-3 textDarkLight form-group form-check" style="border: 2px solid white;" id="div' + value.so_no + '"> \
    //                                             <div class="form-check"> \
    //                                                 <input class="form-check-input" type="checkbox" value="' + value.so_no + '" name="SOcheck" id="' + value.so_no + '"> \
    //                                                 <h4 class="my-0 blue"><label class="form-check-label" for="' + value.so_no + '"><b>' + value.so_no + '</b></label></h4> \
    //                                             </div> \
    //                                             <p class="my-0 textLight"><b>สร้างเมื่อ</b> ' + value.so_date + ' ' + value.so_time + '</p> \
    //                                             <hr> \
    //                                             <div id="div2' + value.so_no + '"></div> \
    //                                             <h6 class="my-0 textLight2" style="text-align:right;"><b>ราคา</b> ฿' + formatNumber(value.total_sales_price) + '</h6> \
    //                                             <h6 class="my-0 textLight2" style="text-align:right;"><b>ส่วนลด</b> ฿' + formatNumber(value.discountso) + '</h6> \
    //                                             <h6 class="mt-1 mb-0" style="text-align:right;"><b>ราคารวม</b> ฿' + formatNumber(value.total_sales_price - value.discountso) + '</h6> \
    //                                         </div>');          
    //                 soList.push(value.so_no);
    //                 hasSoNoSox = true;
    //             }
    //         });

    //         if(hasSoNoSox) {
                
    //             $('#sos').prepend('<div class="container bg-white mx-0 mt-3 p-3 textDarkLight form-group form-check" style="border: 2px solid white;"> \
    //                                             <div class="form-check"> \
    //                                                 <input class="form-check-input" type="checkbox" id="selectall" onclick="toggle()"> \
    //                                                 <h5 class="my-0 textDarkLight"><label class="form-check-label" for="selectall">เลือกทั้งหมด</label></h5> \
    //                                             </div> \
    //                                         </div>');
                                            
    //             angular.forEach($scope.sos, value => {
    //                 $('#div2' + value.so_no).append('<div class="row my-2"> \
    //                                                         <div class="col-3 col-lg-2"> \
    //                                                             <img src="https://fistosports.com/assets/images/no-img.png" alt="Lamp" style="width:100%"> \
    //                                                         </div> \
    //                                                         <div class="col"> \
    //                                                             <h6><b>' + value.product_name + '</b></h6> \
    //                                                             <h6>฿' + formatNumber(value.sales_price) + '</h6> \
    //                                                             <h6>x ' + value.quantity + '</h6> \
    //                                                         </div> \
    //                                                     </div>');
    //                 $scope.weight += (value.weight * value.quantity);
    //                 $('#chooseTranport').append($scope.weight + '. ');
    //             });
                
    //             $('#sos').append('<button type="button" class="btn btn-default btn-block" style="text-align:center;" onclick="showTransport()">คำนวณค่าจัดส่ง</button>');  
                
    //         } else {

    //             $('#sos').html('<h5>ไม่มี Sales Order ที่ยังไม่สร้าง SOX</h5>');

    //         }
            
    //     }
        
    // }

    
    $scope.showSos = () => {

        $scope.weight = 0;
                
        if($('#customerName').val() == '') {
            
            $('#showSosValidate1').modal('toggle');
            
        } else {
            
            $('#customerName').attr('disabled', true);
            $('#showSos').attr('disabled', true);
            $('body, html').animate({ scrollTop: $("#hr1").offset().top }, 600);
            
            var soList = [];
            var hasSoNoSox = false;
            
            $('#sos').html('');
            
            angular.forEach($scope.sos, value => {

                if (parseFloat(value.discountso) == 0) {
                    var summary_text = '';
                } else {
                    var summary_text = '<b>ราคา</b> ฿' + formatNumber(value.total_sales_price) + '<br> \
                                        <b>ส่วนลด</b> ฿' + formatNumber(value.discountso) + '<br>';
                }

                if(!soList.includes(value.so_no) && value.customer_tel == $('#customerName').val()) {
                    $('#sos').append('<div class="sox-content" id="div' + value.so_no + '"> \
                                            <div class="flex justify-between items-center mb-2"> \
                                                <div class="select-item"> \
                                                    <input class="mr-2" type="checkbox" value="' + value.so_no + '" name="SOcheck" id="' + value.so_no + '"> \
                                                    <label for="item_1">' + value.so_no + '</label> \
                                                </div> \
                                                <div class="created_at">สร้างเมื่อ ' + value.so_date + ' ' + value.so_time + '</div> \
                                            </div> \
                                            <div id="div2' + value.so_no + '"></div> \
                                            <div style="text-align: right; font-size: 0.75rem;"> \
                                                ' + summary_text + '\
                                                <b>ราคารวม</b> ฿' + formatNumber(value.total_sales_price - value.discountso) + 
                                            '</div> \
                                        </div> \
                                        <hr>');
                    soList.push(value.so_no);
                    hasSoNoSox = true;
                }
            });

            if(hasSoNoSox) {
                
                $('#sos').prepend('<div class="sox-content"> \
                                        <div class="select-all"> \
                                            <input class="mr-2" type="checkbox" id="selectall" onclick="toggle()"> \
                                            <label for="checkbox_select_all">เลือกทั้งหมด</label> \
                                        </div> \
                                    </div> \
                                    <hr>');
                                            
                angular.forEach($scope.sos, value => {
                    $('#div2' + value.so_no).append('<div class="flex items-start" style="margin-top: 1rem;"> \
                                                        <img class="thumbnail" src="https://fistosports.com/assets/images/no-img.png"> \
                                                        <div style="width:100%;"> \
                                                            <div class="title">' + value.product_name + '</div> \
                                                            <div class="pricing"> \
                                                                <div class="font-semibold">฿' + formatNumber(value.sales_price) + '</div> \
                                                                <div class="text-primary-1" style="float: right;">x ' + value.quantity + '</div> \
                                                            </div> \
                                                        </div> \
                                                    </div>');
                    $scope.weight += (value.weight * value.quantity);
                });
                
                $('#sos').append('<div class="p-5"><button class="button block" onclick="showTransport()">คำนวณค่าจัดส่ง</button></div>');

            } else {

                $('#sos').html('<h5>ไม่มี Sales Order ที่ยังไม่สร้าง SOX</h5>');

            }
            
        }
        
    }

    $scope.back = () => location.replace('https://liff.line.me/1655997889-JnGWnG3L');

});

var sos = [];
    
function showTransport(){
    
    sos = [];
    var inputElements = document.getElementsByName('SOcheck');
    var differentProject = false;
    $('#chooseTranport').html('');
    
    for(var i = 0; inputElements[i]; ++i) {
        soNoSoxs.forEach(function(value){
            if(inputElements[i].checked && value.so_no == inputElements[i].value) {
                if(sos.length == 0) {
                    sos.push(value);
                } else {
                    if(value.so_no.substring(0, 1) == sos[0].so_no.substring(0, 1)) {
                        sos.push(value);
                    } else {
                        differentProject = true;
                    }
                }
            }
        });
    }
    
    if(differentProject){
        
        $('#showSosValidate3').modal('toggle');
        
    } else if(sos.length == 0){
        
        $('#showSosValidate2').modal('toggle');
        
    }  else if(sos.length > 0) {
        
        $('#selectall').attr('disabled', true);
        $('#validateButton').attr('disabled', true);
        
        for(var i = 0; inputElements[i]; ++i) {
            inputElements[i].disabled = true;
        }
        
        $.post('/my_orders/calculate_transportation', {
            post : true,
            sos : JSON.stringify(sos),
            so_type : $('#soType').val()
        }, function(data) {
            $('#chooseTranport').append(data);
            $('body, html').animate({ scrollTop: $("#chooseTranport").offset().top }, 600);
        });
        
    }
    
}

add_modal('confirm_modal', 'ยืนยันการสร้าง SOX?<br><button type="button" class="button block" onclick="post_create_sox()">ยืนยัน</button>');

function formValidate() {
    $('#confirm_modal').modal('toggle');
}

function post_create_sox(){
        
    $('#confirm_modal').modal('hide');
    
    var transportElements = document.getElementsByName('transportRadio');
    
    for(var i = 0; transportElements[i]; ++i){
        if(transportElements[i].checked){
            transportPrice = transportElements[i].value;
            bin_id = transportElements[i].id;
        }
    }
    
    $.post("/my_orders/post_create_sox", {
        post : true,
        sos : JSON.stringify(sos),
        so_type : $('#soType').val(),
        transportPrice : transportPrice,
        bin_id : bin_id
    }, function(data) {
        if (data == 'error') {
            add_modal('errorModal', 'เกิดปัญหาระหว่างการออก SOX กดออกใหม่อีกครั้ง');
            $('#errorModal').modal('toggle');
        } else {
            add_modal('successModal', 'บันทึก ' + data +' สำเร็จ');
            $('#successModal').modal('toggle');
            $('#successModal').on('hide.bs.modal', function (e) {
                window.location.replace('https://liff.line.me/1655997889-JnGWnG3L');
            });
        }
    });
    
}