function check_is_liked_and_redirect(line_user_id){
  let url = `${API_URL}api/check_line_user_id?line_user_id=${line_user_id}`;
  let login_url = `/signin?liff_id=${LIFF_ID}`;
  $.get( url, function( data ) {
    if(data.is_existing){
      get_cba_profile(line_user_id);
      send_analytics(line_user_id, personal_info_request_text, personal_info_response_intent);
    }else{// to login
      location.href = login_url;
    }
  });
}

function get_date_format(date){
  let d =new Date(date);
  let day = ('0' + (d.getDate())).slice(-2);
  let month = ('0' + (d.getMonth()+1)).slice(-2);
  let year = d.getFullYear() -2000;
  if(year > 500 ){
    year = year - 543;
  }
  return `${day}.${month}.${year}`;
}

function numberWithCommas(x) {
  return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}