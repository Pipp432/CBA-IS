const BRR_ANALYTICS_URL= 'https://line-gw.cbachula.com/event/send/cba';

function send_analytics(line_user_id, request_text, response_intent){
  $.post(
    BRR_ANALYTICS_URL
    , {
        user_id:line_user_id ,
        platform:'line', 
        request_text:request_text, 
        response_intent:response_intent
      }
    ).done(function(response){
      // console.log(response);
  });
}