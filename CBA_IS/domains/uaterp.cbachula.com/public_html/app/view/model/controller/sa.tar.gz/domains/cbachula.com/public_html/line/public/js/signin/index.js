add_modal('signInValidateModal1', 'กรุณากรอกรหัส SP และรหัสผ่านของคุณ');
add_modal('signInValidateModal2', 'รหัส SP หรือรหัสผ่านไม่ถูกต้อง');
add_modal('signInValidateModal3', 'ไลน์ไอดีนี้ถูกใช้งานแล้ว');

var login_request_text = "/login";
var login_response_intent = "pageview_login"

function signInValidate() {
    if($("#signInId").val() == "" || $("#signInPassword").val() == "") {
        $('#signInValidateModal1').modal('toggle');
    } else {
        signIn();
    }
}

function signIn() {

    liff.init({liffId: liff_id}, () => {
        liff.getProfile().then(result => {
            send_analytics(result.userId, login_request_text, login_response_intent);
            $.post("/signin/authenticate", {
                employee_id: $("#signInId").val(),
                employee_password: $("#signInPassword").val(),
                line_user_id: result.userId
            }, function(result) {
                if (result == 'fail1') {
                    $('#signInValidateModal2').modal('toggle');
                } else if (result == 'fail2') {
                    $('#signInValidateModal3').modal('toggle');
                } else {
                    location.replace('/signin/welcome?liff_id=' + liff_id);
                }
            });
        });
    }, err => console.error(err.code, error.message));

}