app.controller('appController', function($scope, $http) {

    $scope.done = false;
    $scope.leaderboards = [];

    liff.init({liffId: '1655997889-qgnvGnaz'}, () => {
        liff.getProfile().then(result => {
            $http.get('/api/check_line_user_id?line_user_id=' + result.userId).then((response) => {
                if (response.data.is_existing) {
                    $http.get('/api/leaderboard?line_user_id=' + result.userId).then((response) => {
                        $scope.leaderboards = response.data;
                        $scope.done = true;
                    });
                } else {
                    location.assign('/signin?link_token=xxx');
                }
            });
        });
    }, err => console.error(err.code, error.message));

});