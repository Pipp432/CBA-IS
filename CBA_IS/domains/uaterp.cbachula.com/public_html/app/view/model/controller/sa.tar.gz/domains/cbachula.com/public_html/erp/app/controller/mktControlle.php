<?php

namespace controller;

use _core\controller;
use _core\helper\input;
use _core\helper\session;
use _core\helper\uri;

class mktController extends controller {

    public function index() { 
        $this->requirePostition("mkt");
        $this->err404();
    }
    
    public function demo() {
        if(empty(uri::get(2))) {
            $this->requirePostition("mkt");
            $this->view->setTitle("DEMO");
            $this->view->suppliers = $this->model->getSuppliers();
            $this->view->products = $this->model->getProducts();
            $this->view->render("mkt/demo", "navbar");
        }
    }
	
	public function t_price() {
        if(empty(uri::get(2))) {
            $this->view->setTitle("Calculate Transportation Price");
            $this->view->suppliers = $this->model->getSuppliers();
            $this->view->products = $this->model->getProductsForT();
            $this->view->render("mkt/t_price", "navbar");
        } 
    }
	public function calculateTransportation() {
        
        $this->requirePost();
        
        // $listSO = json_decode(input::post('list_so'), true);
        // $weight = $this->model->calculateWeight($listSO);
        // $isBangkok = $this->model->isBangkok($listSO[0]);
        
        // $sos = json_decode(input::post('sos'), true);
        
		$priceList = $this->model->calculateTransportationPrice();
		if (isset($pricelist['error'])){
			echo 'error';
		} else{
			echo '<div class="form-check" style="margin-bottom:1rem;">';
			echo '<input class="form-check-input" type="radio" name="transportRadio" id="'.$priceList['bin_id'].'" value="'.$priceList['price'].'" checked>';
			echo '<lable>Note : <b>'.$priceList['error'].'</b> </lable> </br>';
			echo '<lable>กรุงเทพและปริมณฑล : <b>'.$priceList['price'].'</b> บาท</lable> </br>';
			echo '<lable>อื่นๆ : <b>'.$priceList['oprice'].'</b> บาท</lable>';
			echo '</div>';
		}
		
    }

    public function sales_order() {
        if(empty(uri::get(2))) {
            $this->requirePostition("mkt");
            $this->view->setTitle("Sales Order (SO)");
            $this->view->suppliers = $this->model->getSuppliers();
            $this->view->products = $this->model->getProducts();
            $this->view->render("mkt/sales_order", "navbar");
        } else if (uri::get(2)==='get_customer_name') {
            $this->positionEcho('mkt', $this->model->getCustomerName());
        } else if (uri::get(2)==='post_so_items') {
            $this->positionEcho('mkt', $this->model->addSo());
        }
    }
	
    
    public function commart() {
        if(empty(uri::get(2))) {
            $this->requirePostition("mkt");
            $this->view->setTitle("CBA x COMMART");
            $this->view->products = $this->model->getCommartProduct();
            $this->view->render("mkt/commart", "navbar");
        } else if (uri::get(2)==='post_items') {
            $this->positionEcho('mkt', $this->model->addCommart());
        }
    }

    public function purchase_order() {
        if(empty(uri::get(2))) {
            $this->requirePostition("mkt");
            $this->view->setTitle("Purchase Order (PO)");
            $this->view->suppliers = $this->model->getSupplierList();
            $this->view->sos = $this->model->getOrderInstallSo();
            $this->view->products = $this->model->getStockProduct();
            $this->view->render("mkt/purchase_order", "navbar");
        } else if (uri::get(2)==='post_po_items') {
            $this->positionEcho('mkt', $this->model->addPo());
        }
    }

    public function confirm_install() {
        if(empty(uri::get(2))) {
            $this->requirePostition("mkt");
            $this->view->setTitle("Confirm Install (CI)");
            $this->view->pos = $this->model->getInstallPo();
            $this->view->render("mkt/confirm_install", "navbar");
        } else if (uri::get(2)==='get_po_install_ci') {
            $this->positionEcho('mkt', $this->model->getInstallPo());
        } else if (uri::get(2)==='post_ci_items') {
            $this->positionEcho('mkt', $this->model->addCi());
        }  
    }
    
    public function request_counter_sales() {
        if(empty(uri::get(2))) {
            $this->requirePostition("mkt");
            $this->view->setTitle("Request Counter Sales (RCS)");
            $this->view->locations = $this->model->getLocation();
            $this->view->products = $this->model->getProducts();
            $this->view->render("mkt/request_counter_sales", "navbar");
        } else if (uri::get(2)==='post_cs_items') {
            $this->positionEcho('mkt', $this->model->addCs());
        }
    }
    
    public function xiaomi_report() {
        if(empty(uri::get(2))) {
            $this->requirePostition("mkt");
            $this->view->setTitle("Xiaomi Report");
            $this->view->report = $this->model->getXiaomiReport();
            $this->view->render("mkt/xiaomi_report", "navbar");
        } else if (uri::get(2)==='post_xr_items') {
            $this->positionEcho('mkt', $this->model->addXr());
        } else if (uri::get(2)==='download') {
            
            header("Content-type: application/vnd.ms-excel");
            header("Content-Disposition: attachment; filename=xiaomi_report.xls");
            $data = $this->model->getXiaomiReportDownload();
            
            echo '<table style="width:100%">';
            
                echo '<tr>';
                    echo '<th>product_no</th>';
                    echo '<th>product_description</th>';
                    echo '<th>quantity</th>';
                    echo '<th>purchase</th>';
                echo '</tr>';
                
                foreach($data as $value) {
                    echo '<tr>';
                        echo '<td>'.$value['product_no'].'</td>';
                        echo '<td>'.$value['product_description'].'</td>';
                        echo '<td>'.$value['quantity'].'</td>';
                        echo '<td>'.$value['purchase'].'</td>';
                    echo '</tr>';
                }
                
            echo '</table>';
            
        }
    }
    
    public function dashboard() {
        if(empty(uri::get(2))) {
            // $this->requirePostition("mkt");
            $this->view->setTitle("Dashboard");
            $this->view->sos = $this->model->getDashboradSo();
            $this->view->pos = $this->model->getDashboradPo();
            $this->view->css = $this->model->getDashboradCs();
            $this->view->render("mkt/dashboard", "navbar");
        } else if (uri::get(2)==='get_dashboard') {
            $this->positionEcho('mkt', $this->model->getDashborad());
        }
    }
    
    public function sales_report() {
        
        header("Content-type: application/vnd.ms-excel; charset=UTF-8");
        header("Content-Disposition: attachment; filename=sales_report.xls");
        $data = $this->model->getSalesReport();
        echo "\xEF\xBB\xBF";
        echo '<table style="width:100%">';
        
            echo '<tr>';
                echo '<th>so_no</th>';
                echo '<th>so_week</th>';
                echo '<th>so_date</th>';
                echo '<th>so_time</th>';
                echo '<th>product_line</th>';
                echo '<th>product_no</th>';
                echo '<th>product_name</th>';
                echo '<th>category_name</th>';
                echo '<th>sub_category</th>';
                echo '<th>supplier_name</th>';
                echo '<th>quantity</th>';
                echo '<th>total_no_vat</th>';
                echo '<th>total_sales</th>';
                echo '<th>total_point</th>';
                echo '<th>total_commission</th>';
                echo '<th>margin</th>';
                echo '<th>sp</th>';
                echo '<th>ce</th>';
            echo '</tr>';
            
            foreach($data as $value) {
                echo '<tr>';
                    echo '<td>'.$value['so_no'].'</td>';
                    echo '<td>'.$value['so_week'].'</td>';
                    echo '<td>'.$value['so_date'].'</td>';
                    echo '<td>'.$value['so_time'].'</td>';
                    echo '<td>'.$value['product_line'].'</td>';
                    echo '<td>'.$value['product_no'].'</td>';
                    echo '<td>'.$value['product_name'].'</td>';
                    echo '<td>'.$value['category_name'].'</td>';
                    echo '<td>'.$value['sub_category'].'</td>';
                    echo '<td>'.$value['supplier_name'].'</td>';
                    echo '<td>'.$value['quantity'].'</td>';
                    echo '<td>'.$value['total_no_vat'].'</td>';
                    echo '<td>'.$value['total_sales'].'</td>';
                    echo '<td>'.$value['total_point'].'</td>';
                    echo '<td>'.$value['total_commission'].'</td>';
                    echo '<td>'.$value['margin'].'</td>';
                    echo '<td>'.$value['sp'].'</td>';
                    echo '<td>'.$value['ce'].'</td>';
                echo '</tr>';
            }
            
        echo '</table>';
        
    }
    
    public function point_report() {
        
        header("Content-type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        header("Content-Disposition: attachment; filename=point_report.xls");
        $data = $this->model->getPointReport();
        
        echo '<table style="width:100%">';
        
            echo '<tr>';
                echo '<th>date</th>';
                echo '<th>sp</th>';
                echo '<th>product_line</th>';
                echo '<th>ce</th>';
                echo '<th>point</th>';
                echo '<th>remark</th>';
                echo '<th>note</th>';
				echo '<th>type</th>';
				echo '<th>total_sales_no_vat</th>';
				echo '<th>total_sales_vat</th>';
                echo '<th>total_sales_price</th>';
            echo '</tr>';
            
            foreach($data as $value) {
                echo '<tr>';
                    echo '<td>'.$value['date'].'</td>';
                    echo '<td>'.$value['sp'].'</td>';
                    echo '<td>'.$value['product_line'].'</td>';
                    echo '<td>'.$value['ce'].'</td>';
                    echo '<td>'.$value['point'].'</td>';
                    echo '<td>'.$value['remark'].'</td>';
                    echo '<td>'.$value['note'].'</td>';
					echo '<td>'.$value['type'].'</td>';
					echo '<td>'.$value['total_sales_no_vat'].'</td>';
					echo '<td>'.$value['total_sales_vat'].'</td>';
                    echo '<td>'.$value['total_sales_price'].'</td>';
                echo '</tr>';
            }
            
        echo '</table>';
        
    }
    
    
    
    // public function championLeague_report() {
        
    //     header("Content-type: application/vnd.ms-excel");
    //     header("Content-Disposition: attachment; filename=championLeague_report.xls");
    //     $data = $this->model->getChampionLeagueReport();
        
    //     echo '<table style="width:100%">';
        
    //         echo '<tr>';
    //             echo '<th>so_no</th>';
    //             echo '<th>so_date</th>';
    //             echo '<th>so_time</th>';
    //             echo '<th>team_name</th>';
    //             echo '<th>sp</th>';
    //             echo '<th>team_ce_name</th>';
    //             echo '<th>total_sales_price</th>';
    //         echo '</tr>';
            
    //         foreach($data as $value) {
    //             echo '<tr>';
    //                 echo '<td>'.$value['so_no'].'</td>';
    //                 echo '<td>'.$value['so_date'].'</td>';
    //                 echo '<td>'.$value['so_time'].'</td>';
    //                 echo '<td>'.$value['team_name'].'</td>';
    //                 echo '<td>'.$value['sp'].'</td>';
    //                 echo '<td>'.$value['team_ce_name'].'</td>';
    //                 echo '<td>'.$value['total_sales_price'].'</td>';
    //             echo '</tr>';
    //         }
            
    //     echo '</table>';
        
    // }
    
    // public function finalLeague_report() {
        
    //     header("Content-type: application/vnd.ms-excel");
    //     header("Content-Disposition: attachment; filename=finalLeague_report.xls");
    //     $data = $this->model->getFinalLeagueReport();
        
    //     echo '<table style="width:100%">';
        
    //         echo '<tr>';
    //             echo '<th>sp</th>';
    //             echo '<th>ce_id</th>';
    //             echo '<th>rank</th>';
    //             echo '<th>so_no</th>';
    //             echo '<th>total_sales_price</th>';
    //             echo '<th>remark</th>';
    //         echo '</tr>';
            
    //         foreach($data as $value) {
    //             echo '<tr>';
    //                 echo '<td>'.$value['sp'].'</td>';
    //                 echo '<td>'.$value['ce_id'].'</td>';
    //                 echo '<td>'.$value['rank'].'</td>';
    //                 echo '<td>'.$value['so_no'].'</td>';
    //                 echo '<td>'.$value['total_sales_price'].'</td>';
    //                 echo '<td>'.$value['remark'].'</td>';
    //             echo '</tr>';
    //         }
            
    //     echo '</table>';
        
    // }
    
    public function infected_wars_report() {
        
        header("Content-type: application/vnd.ms-excel");
        header("Content-Disposition: attachment; filename=infected_wars_report.xls");
        $data = $this->model->getTournament();
        
        echo '<table style="width:100%">';
        
            echo '<tr>';
                echo '<th>product_line</th>';
                echo '<th>team_name</th>';
                echo '<th>team_ce</th>';
                echo '<th>team_sales</th>';
            echo '</tr>';
            
            foreach($data as $value) {
                echo '<tr>';
                    echo '<td>'.$value['product_line'].'</td>';
                    echo '<td>'.$value['team_name'].'</td>';
                    echo '<td>'.$value['team_ce'].'</td>';
                    echo '<td>'.$value['team_sales'].'</td>';
                echo '</tr>';
            }
            
        echo '</table>';
        
    }
    
    public function get_supplier_list() {
        $this->positionEcho('mkt', $this->model->getSupplierList());
    }

}
