var LIFF_ID = null;
var welcome_request_text = "/welcome";
var welcome_response_intent = "pageview_welcome"


function get_line_profile() {
  liff.getProfile().then(result => {
    $('#profile_img').attr('src', result.pictureUrl);
    $('#profile_name').text(result.displayName);
    send_analytics(result.userId, welcome_request_text, welcome_response_intent);
    get_cba_profile(result.userId);
  }).catch((err) => {
 
  });
}

function get_cba_profile(line_user_id){
  let url = '/api/personal_info?line_user_id=' + line_user_id;
  $.get( url, function( data ) {
    $('#profile_name').text(data.name);
    $('#profile_spid').text(data.sp_id);
    $('#profile_full_point').text(numberWithCommas(data.full_point));
    $('#profile_point').text(numberWithCommas(data.point));
    $('#profile_rank').text(data.rank);
    generateQRCode(data.sp_id);
  });
}

function redirect() {
  location.replace('https://liff.line.me/' + LIFF_ID);
}


function initializeLiff(liff_id) {
  LIFF_ID = liff_id;
    
    liff.init({
          liffId: LIFF_ID
      })
      .then(() => {
          get_line_profile();
      })
      .catch((err) => {
        console.log(err);
      });
    
}