app.controller('appController', function($scope, $http) {

    $scope.done = false;
    $scope.orders = [];

    liff.init({liffId: '1655997889-JnGWnG3L'}, () => {
        liff.getProfile().then(result => {
            send_analytics(result.userId, '/my_orders', 'pageview_my_orders');
            $http.get('/api/check_line_user_id?line_user_id=' + result.userId).then((response) => {
                if (response.data.is_existing) {
                    $http.get('/my_orders/get_my_orders?line_user_id=' + response.data.line_user_id).then((response) => {
                        $scope.orders = response.data;
                        $scope.done = true;
                        angular.forEach($scope.orders, value => {

                            if (value.done == -1 && value.slip_uploaded == 0 && value.cancelled == 0 && value.payment != 1) {
                                value.status = 'ยังไม่ชำระเงิน';
                                $('#status_color').css('background-color', 'DarkGrey');
                            } else if (value.done == -1 && value.slip_uploaded == 1 && value.cancelled == 0 && value.payment != 1) {
                                value.status = 'กำลังตรวจสอบสลิป';
                                $('#status_color').css('background-color', 'Aquamarine');
                            } else if (value.done == 0 && value.cancelled == 0 && value.tracking_number == null && value.payment != 1) {
                                value.status = 'ชำระเงินแล้ว';
                                $('#status_color').css('background-color', 'CornflowerBlue');
                            } else if (value.done == 0  && value.cancelled == 0 && value.tracking_number != null && value.payment != 1) {
                                value.status = 'กำลังจัดส่ง';
                                $('#status_color').css('background-color', 'DarkKhaki');
                            } else if (value.done == 1 && value.cancelled == 0 && value.payment != 1) {
                                value.status = 'จัดส่งแล้ว';
                                $('#status_color').css('background-color', 'DarkOliveGreen');
                            } 
                            
                            else if (value.done == -1 && value.slip_uploaded == 0 && value.cancelled == 0 && value.payment == 1 && value.iv == 0) {
                                value.status = 'รอการจัดส่ง (จ่ายหลัง)';
                                $('#status_color').css('background-color', 'Aquamarine');
                            } else if (value.done == 1 && value.slip_uploaded == 1 && value.cancelled == 0 && value.payment == 1 && value.iv == 0) {
                                value.status = 'รอใบกำกับภาษี (จ่ายหลัง)';
                                $('#status_color').css('background-color', 'CornflowerBlue');
                            } else if (value.done == 1 && value.slip_uploaded == 1 && value.cancelled == 0 && value.payment == 1 && value.iv == 1) {
                                value.status = 'กำลังตรวจสอบสลิป (จ่ายหลัง)';
                                $('#status_color').css('background-color', 'DarkKhaki');
                            } else if (value.done == 1 && value.slip_uploaded == 0 && value.cancelled == 0 && value.payment == 1) {
                                value.status = 'ยังไม่ชำระเงิน (จ่ายหลัง)';
                                $('#status_color').css('background-color', 'DarkOliveGreen');
                            } else if (value.done == 2 && value.cancelled == 0 && value.payment == 1) {
                                value.status = 'ชำระเงินแล้ว (จ่ายหลัง)';
                                $('#status_color').css('background-color', 'Crimson');
                            }  
                            
                            else if (value.cancelled == 1) {
                                value.status = 'ยกเลิกแล้ว';
                                $('#status_color').css('background-color', 'Crimson');
                            }
                            
                            else {
                                value.status = 'error';
                                $('#status_color').css('background-color', 'Black');
                            } 
                            
                        });
                    });
                } else {
                    location.assign('/signin?liff_id=1655997889-JnGWnG3L');
                }
            });
        });
    }, err => console.error(err.code, error.message));

    $scope.show_create_sox = () => location.replace('/my_orders/create_sox?liff_id=1655997889-JnGWnG3L');
    $scope.show_sox_detail = sox_no => location.replace('/my_orders/sox_detail?sox_no=' + sox_no);

});